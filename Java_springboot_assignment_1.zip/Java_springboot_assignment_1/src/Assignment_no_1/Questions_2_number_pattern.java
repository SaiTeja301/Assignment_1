package Assignment_no_1;

public class Questions_2_number_pattern 
{
   public void numbers()
   {
	   for(int i=1;i<=5;i++)
	   {
		   for(int j=1;j<=5;j++)
		   {
			   System.out.print(i);
		   }
		   System.out.println();
	   }
	  
   }
   public static void main(String args[])
   {
	   Questions_2_number_pattern qe = new Questions_2_number_pattern();
	   qe.numbers();
   }
}
